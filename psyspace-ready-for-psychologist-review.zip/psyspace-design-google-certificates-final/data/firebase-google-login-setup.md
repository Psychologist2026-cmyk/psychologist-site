# Google-вхід через Firebase

1. Firebase Console → Create project.
2. Build → Authentication → Get started.
3. Sign-in method → Google → Enable.
4. Settings → Authorized domains → додати домен Netlify.
5. Project settings → Web app → скопіювати firebaseConfig.
6. Вставити config у `script.js` у блок `FIREBASE_GOOGLE_READY`.
7. Додати Firebase SDK у `auth.html`.
8. Замінити `signInWithGooglePrepared()` на реальний `signInWithPopup`.

Логіка:
- якщо Google email = psychologist@example.com → `admin.html`;
- інші email → `client-dashboard.html`.
